<?php
echo "tu hai kahan";
?>
